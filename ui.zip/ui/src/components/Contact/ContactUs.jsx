import React from 'react'
import {HeaderNavBar} from '../layout/HeaderNavBar'



function ContactUs() {
  return (
    <div className='ContactPage '>
    <HeaderNavBar/>
     <div className='justify-content-center content'>kmvlkvnvnvjnvdvkjvndsknkjdjcjcjc akk
     njncjnkjcnkjnkjnkjnkjnkjcakjcckc </div>

    </div>
  )
}

export default ContactUs